import 'package:flutter/material.dart';
import 'package:vantag/l10n/app_localizations.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import '../services/services.dart';
import '../theme/theme.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});

  @override
  State<NotificationSettingsScreen> createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  final _notificationService = NotificationService();
  Map<String, bool> _settings = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _notificationService.getSettings();
    if (mounted) {
      setState(() {
        _settings = settings;
        _isLoading = false;
      });
    }
  }

  Future<void> _updateSetting(String key, bool value) async {
    setState(() => _settings[key] = value);
    await _notificationService.updateSetting(key, value);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Scaffold(
      backgroundColor: context.appColors.background,
      appBar: AppBar(
        backgroundColor: context.appColors.background,
        leading: IconButton(
          icon: Icon(PhosphorIconsDuotone.arrowLeft, color: context.appColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          l10n.notificationSettings,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: context.appColors.textPrimary,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Master switch
                  _buildMasterSwitch(context),
                  const SizedBox(height: 24),

                  // Notification types
                  if (_settings['enabled'] == true) ...[
                    Text(
                      l10n.notificationTypes,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: context.appColors.textSecondary,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 12),

                    _buildSettingTile(
                      title: l10n.awarenessReminder,
                      subtitle: l10n.awarenessReminderDesc,
                      key: 'delayedAwareness',
                      icon: PhosphorIconsDuotone.brain,
                    ),
                    const SizedBox(height: 12),

                    _buildSettingTile(
                      title: l10n.giveUpCongrats,
                      subtitle: l10n.giveUpCongratsDesc,
                      key: 'reinforce',
                      icon: PhosphorIconsDuotone.confetti,
                    ),
                    const SizedBox(height: 12),

                    _buildSettingTile(
                      title: l10n.streakReminder,
                      subtitle: l10n.streakReminderDesc,
                      key: 'streakReminder',
                      icon: PhosphorIconsDuotone.flame,
                    ),
                    const SizedBox(height: 12),

                    _buildSettingTile(
                      title: l10n.weeklySummary,
                      subtitle: l10n.weeklySummaryDesc,
                      key: 'weeklyInsight',
                      icon: PhosphorIconsDuotone.chartBar,
                    ),

                    const SizedBox(height: 32),

                    // Info note
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: context.appColors.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: context.appColors.cardBorder),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            PhosphorIconsDuotone.info,
                            size: 18,
                            color: context.appColors.textTertiary,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              l10n.nightModeNotice,
                              style: TextStyle(
                                fontSize: 13,
                                color: context.appColors.textTertiary,
                                height: 1.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
    );
  }

  Widget _buildMasterSwitch(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isEnabled = _settings['enabled'] ?? true;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isEnabled
            ? context.appColors.primary.withValues(alpha: 0.1)
            : context.appColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isEnabled
              ? context.appColors.primary.withValues(alpha: 0.3)
              : context.appColors.cardBorder,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: isEnabled
                  ? context.appColors.primary.withValues(alpha: 0.2)
                  : context.appColors.surfaceLight,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              isEnabled ? PhosphorIconsDuotone.bellRinging : PhosphorIconsDuotone.bellSlash,
              size: 24,
              color: isEnabled ? context.appColors.primary : context.appColors.textTertiary,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  l10n.notifications,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: context.appColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  isEnabled ? l10n.on : l10n.off,
                  style: TextStyle(
                    fontSize: 13,
                    color: isEnabled ? context.appColors.primary : context.appColors.textTertiary,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: isEnabled,
            onChanged: (value) => _updateSetting('enabled', value),
            activeTrackColor: context.appColors.primary,
          ),
        ],
      ),
    );
  }

  Widget _buildSettingTile({
    required String title,
    required String subtitle,
    required String key,
    required IconData icon,
  }) {
    final isEnabled = _settings[key] ?? true;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: context.appColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: context.appColors.cardBorder),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: context.appColors.surfaceLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              size: 20,
              color: isEnabled ? context.appColors.textSecondary : context.appColors.textTertiary,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: isEnabled ? context.appColors.textPrimary : context.appColors.textTertiary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 12,
                    color: context.appColors.textTertiary,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: isEnabled,
            onChanged: (value) => _updateSetting(key, value),
            activeTrackColor: context.appColors.primary,
          ),
        ],
      ),
    );
  }
}
