import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/currency_provider.dart';

import 'app_theme.dart';

/// Premium Fintech Design System
/// Inspired by Revolut, N26, Nubank
///
/// IMPORTANT: Colors now delegate to AppColors for consistency.
/// Use AppColors directly in new code.
@Deprecated('Use AppColors directly for colors. PremiumTheme widgets still available.')
class PremiumTheme {
  PremiumTheme._();

  // ============================================
  // COLORS - Delegated to AppColors for consistency
  // ============================================
  static Color get background => AppColors.background;
  static Color get surface => AppColors.surface;
  static Color get surfaceLight => AppColors.surfaceLight;
  static Color get cardBorder => AppColors.cardBorder;

  static Color get primary => AppColors.primary;
  static Color get primaryLight => AppColors.primaryLight;
  static Color get secondary => AppColors.secondary;

  static Color get success => AppColors.success;
  static Color get successGlow => AppColors.success.withValues(alpha: 0.25);
  static Color get warning => AppColors.warning;
  static Color get warningGlow => AppColors.warning.withValues(alpha: 0.25);
  static Color get error => AppColors.error;
  static Color get errorGlow => AppColors.error.withValues(alpha: 0.25);

  static Color get textPrimary => AppColors.textPrimary;
  static Color get textSecondary => AppColors.textSecondary;
  static Color get textTertiary => AppColors.textTertiary;

  // ============================================
  // GRADIENTS - Delegated to AppGradients
  // ============================================
  static LinearGradient get primaryGradient => AppGradients.primary;
  static LinearGradient get successGradient => AppGradients.success;
  static LinearGradient get errorGradient => AppGradients.error;
  static LinearGradient get warningGradient => AppGradients.warning;
  static LinearGradient get cardGradient => AppGradients.card;

  // ============================================
  // GLASSMORPHISM VALUES
  // ============================================
  static const double glassBlur = 10.0;
  static const double glassBorderWidth = 0.5;
  static const Color glassBorderColor = Color(0x20FFFFFF);
  static const Color glassBackground = Color(0x08FFFFFF);

  // ============================================
  // ANIMATION DURATIONS
  // ============================================
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration normal = Duration(milliseconds: 250);
  static const Duration slow = Duration(milliseconds: 400);
  static const Duration counting = Duration(milliseconds: 800);

  // ============================================
  // ANIMATION CURVES
  // ============================================
  static const Curve defaultCurve = Curves.easeOutCubic;
  static const Curve bounceCurve = Curves.elasticOut;
  static const Curve smoothCurve = Curves.easeInOutCubic;
}

/// Glassmorphic Card Widget
class PremiumGlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;
  final Color? glowColor;
  final double glowIntensity;
  final VoidCallback? onTap;

  const PremiumGlassCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.borderRadius = 20,
    this.glowColor,
    this.glowIntensity = 0.3,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        boxShadow: glowColor != null
            ? [
                BoxShadow(
                  color: glowColor!.withValues(alpha: glowIntensity),
                  blurRadius: 20,
                  spreadRadius: -5,
                ),
              ]
            : null,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: PremiumTheme.glassBlur,
            sigmaY: PremiumTheme.glassBlur,
          ),
          child: GestureDetector(
            onTap: onTap,
            child: Container(
              padding: padding ?? const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: PremiumTheme.cardGradient,
                borderRadius: BorderRadius.circular(borderRadius),
                border: Border.all(
                  color: PremiumTheme.glassBorderColor,
                  width: PremiumTheme.glassBorderWidth,
                ),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

/// Animated Counting Number Widget
class CountingNumber extends StatefulWidget {
  final double value;
  final TextStyle? style;
  final String prefix;
  final String suffix;
  final int decimals;
  final Duration duration;
  final bool useGrouping;

  const CountingNumber({
    super.key,
    required this.value,
    this.style,
    this.prefix = '',
    this.suffix = '',
    this.decimals = 0,
    this.duration = const Duration(milliseconds: 800),
    this.useGrouping = true,
  });

  @override
  State<CountingNumber> createState() => _CountingNumberState();
}

class _CountingNumberState extends State<CountingNumber>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  double _previousValue = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);
    _setupAnimation();
    _controller.forward();
  }

  void _setupAnimation() {
    _animation = Tween<double>(
      begin: _previousValue,
      end: widget.value,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
  }

  @override
  void didUpdateWidget(CountingNumber oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value) {
      _previousValue = oldWidget.value;
      _setupAnimation();
      _controller.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _formatNumber(double value) {
    if (widget.useGrouping) {
      final parts = value.toStringAsFixed(widget.decimals).split('.');
      final intPart = parts[0].replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
        (match) => '${match[1]}.',
      );
      if (parts.length > 1 && widget.decimals > 0) {
        return '$intPart,${parts[1]}';
      }
      return intPart;
    }
    return value.toStringAsFixed(widget.decimals);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Text(
          '${widget.prefix}${_formatNumber(_animation.value)}${widget.suffix}',
          style: widget.style,
        );
      },
    );
  }
}

/// Premium Gradient Button
class GradientButton extends StatefulWidget {
  final String text;
  final VoidCallback? onPressed;
  final Gradient? gradient;
  final double height;
  final double borderRadius;
  final bool isLoading;
  final IconData? icon;

  const GradientButton({
    super.key,
    required this.text,
    this.onPressed,
    this.gradient,
    this.height = 56,
    this.borderRadius = 16,
    this.isLoading = false,
    this.icon,
  });

  @override
  State<GradientButton> createState() => _GradientButtonState();
}

class _GradientButtonState extends State<GradientButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.97,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onTapDown(TapDownDetails details) {
    _controller.forward();
    HapticFeedback.lightImpact();
  }

  void _onTapUp(TapUpDetails details) {
    _controller.reverse();
  }

  void _onTapCancel() {
    _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onPressed != null ? _onTapDown : null,
      onTapUp: widget.onPressed != null ? _onTapUp : null,
      onTapCancel: widget.onPressed != null ? _onTapCancel : null,
      onTap: widget.onPressed,
      child: AnimatedBuilder(
        animation: _scaleAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Container(
              height: widget.height,
              decoration: BoxDecoration(
                gradient: widget.gradient ?? PremiumTheme.primaryGradient,
                borderRadius: BorderRadius.circular(widget.borderRadius),
                boxShadow: [
                  BoxShadow(
                    color: PremiumTheme.primary.withValues(alpha: 0.4),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Center(
                child: widget.isLoading
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (widget.icon != null) ...[
                            Icon(
                              widget.icon!,
                              color: Colors.white,
                              size: 22,
                            ),
                            const SizedBox(width: 10),
                          ],
                          Text(
                            widget.text,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Premium Icon Container with Glow
class GlowingIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  final double containerSize;

  const GlowingIcon({
    super.key,
    required this.icon,
    required this.color,
    this.size = 24,
    this.containerSize = 48,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: containerSize,
      height: containerSize,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.3),
            blurRadius: 12,
            spreadRadius: -2,
          ),
        ],
      ),
      child: Center(
        child: Icon(icon, color: color, size: size),
      ),
    );
  }
}

/// Pressable Widget with Scale Animation
class PremiumPressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double scaleFactor;

  const PremiumPressable({
    super.key,
    required this.child,
    this.onTap,
    this.scaleFactor = 0.97,
  });

  @override
  State<PremiumPressable> createState() => _PremiumPressableState();
}

class _PremiumPressableState extends State<PremiumPressable>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _animation = Tween<double>(
      begin: 1.0,
      end: widget.scaleFactor,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        _controller.forward();
        HapticFeedback.lightImpact();
      },
      onTapUp: (_) => _controller.reverse(),
      onTapCancel: () => _controller.reverse(),
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _animation,
        builder: (context, child) {
          return Transform.scale(scale: _animation.value, child: widget.child);
        },
      ),
    );
  }
}

/// Shimmer Loading Effect
class PremiumShimmer extends StatelessWidget {
  final double width;
  final double height;
  final double borderRadius;

  const PremiumShimmer({
    super.key,
    required this.width,
    required this.height,
    this.borderRadius = 8,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: PremiumTheme.surfaceLight,
        borderRadius: BorderRadius.circular(borderRadius),
      ),
    );
  }
}

/// Premium Stat Card (for income/expense display)
class PremiumStatCard extends StatelessWidget {
  final String label;
  final double value;
  final IconData icon;
  final Color color;
  final String? subtitle;
  final bool isPositive;

  const PremiumStatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    this.subtitle,
    this.isPositive = true,
  });

  @override
  Widget build(BuildContext context) {
    final currencyProvider = context.watch<CurrencyProvider>();
    return PremiumGlassCard(
      glowColor: color,
      glowIntensity: 0.2,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GlowingIcon(
                icon: icon,
                color: color,
                size: 20,
                containerSize: 40,
              ),
              const SizedBox(width: 12),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: PremiumTheme.textSecondary,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              CountingNumber(
                value: value,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w300,
                  color: PremiumTheme.textPrimary,
                  letterSpacing: -0.5,
                ),
                useGrouping: true,
              ),
              const SizedBox(width: 6),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  currencyProvider.code,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: PremiumTheme.textTertiary,
                    letterSpacing: 1.0,
                  ),
                ),
              ),
            ],
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 8),
            Text(
              subtitle!,
              style: TextStyle(
                fontSize: 12,
                color: color,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Cupertino Icons Mapping
class PremiumIcons {
  PremiumIcons._();

  // Navigation
  static IconData get home => CupertinoIcons.house_fill;
  static IconData get chart => CupertinoIcons.chart_bar_fill;
  static IconData get trophy => CupertinoIcons.rosette;
  static IconData get user => CupertinoIcons.person_fill;
  static IconData get plus => CupertinoIcons.plus;
  static IconData get plusCircle => CupertinoIcons.plus_circle_fill;

  // Finance
  static IconData get wallet => CupertinoIcons.creditcard_fill;
  static IconData get money => CupertinoIcons.money_dollar;
  static IconData get creditCard => CupertinoIcons.creditcard_fill;
  static IconData get bank => CupertinoIcons.building_2_fill;
  static IconData get piggyBank => CupertinoIcons.money_dollar_circle_fill;
  static IconData get coins => CupertinoIcons.bitcoin_circle_fill;
  static IconData get currencyDollar => CupertinoIcons.money_dollar;
  static IconData get trendUp => CupertinoIcons.arrow_up_right;
  static IconData get trendDown => CupertinoIcons.arrow_down_right;
  static IconData get receipt => CupertinoIcons.doc_text_fill;

  // Actions
  static IconData get check => CupertinoIcons.checkmark;
  static IconData get checkCircle => CupertinoIcons.checkmark_circle_fill;
  static IconData get x => CupertinoIcons.xmark;
  static IconData get xCircle => CupertinoIcons.xmark_circle_fill;
  static IconData get edit => CupertinoIcons.pencil;
  static IconData get delete => CupertinoIcons.trash_fill;
  static IconData get settings => CupertinoIcons.gear_alt_fill;
  static IconData get share => CupertinoIcons.share;
  static IconData get download => CupertinoIcons.arrow_down_circle_fill;
  static IconData get refresh => CupertinoIcons.arrow_clockwise;

  // Time & Calendar
  static IconData get calendar => CupertinoIcons.calendar;
  static IconData get calendarCheck => CupertinoIcons.calendar_badge_plus;
  static IconData get clock => CupertinoIcons.clock_fill;
  static IconData get timer => CupertinoIcons.timer;
  static IconData get hourglass => CupertinoIcons.hourglass;

  // Categories
  static IconData get food => CupertinoIcons.cart_fill;
  static IconData get shopping => CupertinoIcons.bag_fill;
  static IconData get transport => CupertinoIcons.car_fill;
  static IconData get entertainment => CupertinoIcons.gamecontroller_fill;
  static IconData get health => CupertinoIcons.heart_fill;
  static IconData get education => CupertinoIcons.book_fill;
  static IconData get home_ => CupertinoIcons.house_fill;
  static IconData get utilities => CupertinoIcons.bolt_fill;
  static IconData get subscription => CupertinoIcons.repeat;
  static IconData get gift => CupertinoIcons.gift_fill;
  static IconData get travel => CupertinoIcons.airplane;
  static IconData get coffee => CupertinoIcons.cart_fill;

  // Misc
  static IconData get fire => CupertinoIcons.flame_fill;
  static IconData get lightning => CupertinoIcons.bolt_fill;
  static IconData get star => CupertinoIcons.star_fill;
  static IconData get heart => CupertinoIcons.heart_fill;
  static IconData get bell => CupertinoIcons.bell_fill;
  static IconData get info => CupertinoIcons.info_circle_fill;
  static IconData get warning => CupertinoIcons.exclamationmark_triangle_fill;
  static IconData get question => CupertinoIcons.question_circle_fill;
  static IconData get link => CupertinoIcons.link;
  static IconData get lock => CupertinoIcons.lock_fill;
  static IconData get unlock => CupertinoIcons.lock_open_fill;
  static IconData get eye => CupertinoIcons.eye_fill;
  static IconData get eyeOff => CupertinoIcons.eye_slash_fill;
  static IconData get camera => CupertinoIcons.camera_fill;
  static IconData get image => CupertinoIcons.photo_fill;
  static IconData get sparkle => CupertinoIcons.sparkles;
  static IconData get confetti => CupertinoIcons.sparkles;
  static IconData get target => CupertinoIcons.scope;
  static IconData get rocket => CupertinoIcons.rocket_fill;
  static IconData get crown => CupertinoIcons.star_circle_fill;
  static IconData get shield => CupertinoIcons.shield_fill;
  static IconData get arrowLeft => CupertinoIcons.arrow_left;
  static IconData get arrowRight => CupertinoIcons.arrow_right;
  static IconData get chevronDown => CupertinoIcons.chevron_down;
  static IconData get chevronUp => CupertinoIcons.chevron_up;
  static IconData get chevronLeft => CupertinoIcons.chevron_left;
  static IconData get chevronRight => CupertinoIcons.chevron_right;
  static IconData get menu => CupertinoIcons.line_horizontal_3;
  static IconData get more => CupertinoIcons.ellipsis;
  static IconData get search => CupertinoIcons.search;
  static IconData get filter => CupertinoIcons.slider_horizontal_3;
  static IconData get sort => CupertinoIcons.sort_down;
  static IconData get google => CupertinoIcons.globe;
  static IconData get globe => CupertinoIcons.globe;
  static IconData get language => CupertinoIcons.textformat;
  static IconData get moon => CupertinoIcons.moon_fill;
  static IconData get sun => CupertinoIcons.sun_max_fill;
  static IconData get chatBubble => CupertinoIcons.chat_bubble_fill;
  static IconData get help => CupertinoIcons.question_circle_fill;
  static IconData get signOut => CupertinoIcons.square_arrow_right;
  static IconData get briefcase => CupertinoIcons.briefcase_fill;
  static IconData get building => CupertinoIcons.building_2_fill;
  static IconData get handCoins => CupertinoIcons.hand_raised_fill;
  static IconData get chartLine => CupertinoIcons.graph_square_fill;
  static IconData get medal => CupertinoIcons.rosette;
  static IconData get partyPopper => CupertinoIcons.sparkles;
}
