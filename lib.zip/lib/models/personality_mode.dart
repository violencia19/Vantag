/// AI kişilik modu - hitap tarzını belirler
enum PersonalityMode {
  /// Resmi hitap - "Siz" kullanımı
  professional,

  /// Samimi hitap - "Sen" kullanımı
  friendly,
}
