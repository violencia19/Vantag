import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vantag/l10n/app_localizations.dart';
import '../models/models.dart';
import '../services/services.dart';
import '../theme/theme.dart';
import '../utils/currency_utils.dart';

class ResultCard extends StatelessWidget {
  final ExpenseResult result;
  final String? categoryInsight;
  final String? emotionalMessage;
  final double? amount;
  final ExchangeRates? exchangeRates;
  final String?
      amountCurrencyCode; // Currency of the amount (TRY, USD, EUR, etc.)
  final double dailyHours; // User's work hours per day
  final int workDaysPerWeek; // User's work days per week

  const ResultCard({
    super.key,
    required this.result,
    this.categoryInsight,
    this.emotionalMessage,
    this.amount,
    this.exchangeRates,
    this.amountCurrencyCode,
    this.dailyHours = 8,
    this.workDaysPerWeek = 5,
  });

  String _formatCurrency(double value, {int decimals = 2}) {
    return formatTurkishCurrency(value, decimalDigits: decimals);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final insightService = InsightService();
    final insight = insightService.getExpenseInsight(context, result);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppDesign.spacingXl),
      decoration: BoxDecoration(
        gradient: AppGradients.premiumCard,
        borderRadius: BorderRadius.circular(AppDesign.radiusLarge),
        border: Border.all(
          color: context.appColors.primary.withValues(alpha: 0.2),
          width: 1.5,
        ),
        boxShadow: AppDesign.premiumCardShadow,
      ),
      child: Column(
        children: [
          // Time display - Two blocks side by side
          Builder(
            builder: (context) {
              final timeDisplay = getSimulationTimeDisplay(
                result.hoursRequired,
                workHoursPerDay: dailyHours,
                workDaysPerWeek: workDaysPerWeek,
              );
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Left block: Hours or Years
                  _buildTimeBlock(
                    context: context,
                    value: timeDisplay.value1,
                    unit: timeDisplay.unit1,
                    icon: timeDisplay.isYearMode
                        ? CupertinoIcons.calendar
                        : CupertinoIcons.clock,
                  ),
                  Container(
                    width: 1,
                    height: 60,
                    margin: const EdgeInsets.symmetric(horizontal: 24),
                    color: context.appColors.cardBorder,
                  ),
                  // Right block: Days
                  _buildTimeBlock(
                    context: context,
                    value: timeDisplay.value2,
                    unit: timeDisplay.unit2,
                    icon: CupertinoIcons.sun_max,
                  ),
                ],
              );
            },
          ),

          const SizedBox(height: 20),

          // Emotional message (if exists)
          if (emotionalMessage != null) ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    context.appColors.primary.withValues(alpha: 0.08),
                    context.appColors.primary.withValues(alpha: 0.03),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: context.appColors.primary.withValues(alpha: 0.15),
                ),
              ),
              child: Text(
                emotionalMessage!,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  fontStyle: FontStyle.italic,
                  color: context.appColors.textPrimary,
                  height: 1.4,
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],

          // Insight message
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: context.appColors.surfaceLight,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: context.appColors.warning.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    CupertinoIcons.lightbulb,
                    size: 18,
                    color: context.appColors.warning,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    insight,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: context.appColors.textSecondary,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Category insight
          if (categoryInsight != null) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: context.appColors.info.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  Icon(
                    CupertinoIcons.chart_bar,
                    size: 16,
                    color: context.appColors.info,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      categoryInsight!,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: context.appColors.info,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],

          // Alternative currency display
          if (amount != null && exchangeRates != null) ...[
            const SizedBox(height: 16),
            _buildCurrencyAlternatives(context, l10n),
          ],
        ],
      ),
    );
  }

  Widget _buildCurrencyAlternatives(
    BuildContext context,
    AppLocalizations l10n,
  ) {
    if (amount == null || exchangeRates == null) return const SizedBox.shrink();

    // First convert amount to TRY, then to target currencies
    // amountCurrencyCode tells us what currency the amount is in
    final currencyCode = amountCurrencyCode ?? 'TRY';

    // Convert amount to TRY first
    double amountInTRY;
    if (currencyCode == 'TRY') {
      amountInTRY = amount!;
    } else if (currencyCode == 'USD') {
      amountInTRY = amount! * exchangeRates!.usdRate;
    } else if (currencyCode == 'EUR') {
      amountInTRY = amount! * exchangeRates!.eurRate;
    } else if (currencyCode == 'GBP') {
      // GBP approximation: use USD rate * 1.27
      amountInTRY = amount! * (exchangeRates!.usdRate * 1.27);
    } else if (currencyCode == 'SAR') {
      // SAR is pegged to USD at 3.75
      amountInTRY = amount! * (exchangeRates!.usdRate / 3.75);
    } else {
      amountInTRY = amount!; // Fallback: assume TRY
    }

    // Now convert TRY to each target currency
    final usdAmount = amountInTRY / exchangeRates!.usdRate;
    final eurAmount = amountInTRY / exchangeRates!.eurRate;
    final goldGrams = amountInTRY / exchangeRates!.goldRate;

    // Debug logging for currency conversion
    debugPrint('💱 [ResultCard] Currency Conversion Debug:');
    debugPrint('   Input: $amount $currencyCode');
    debugPrint(
      '   Rates: USD=${exchangeRates!.usdRate}, EUR=${exchangeRates!.eurRate}, GOLD=${exchangeRates!.goldRate}',
    );
    debugPrint('   TRY equivalent: $amountInTRY');
    debugPrint('   Output: USD=$usdAmount, EUR=$eurAmount, GOLD=${goldGrams}g');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppDesign.spacingMd),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            context.appColors.surfaceLight.withValues(alpha: 0.8),
            context.appColors.surfaceLight.withValues(alpha: 0.4),
          ],
        ),
        borderRadius: BorderRadius.circular(AppDesign.radiusMedium),
        border: Border.all(
          color: context.appColors.primary.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                CupertinoIcons.arrow_right_arrow_left,
                size: 14,
                color: context.appColors.textTertiary.withValues(alpha: 0.8),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  l10n.withThisAmountYouCouldBuy(
                    _formatCurrency(amount!, decimals: 2),
                  ),
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: context.appColors.textTertiary,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 16,
            runSpacing: 8,
            children: [
              _buildCurrencyItem(
                context,
                '💵',
                '${_formatCurrency(usdAmount)} USD',
              ),
              _buildCurrencyItem(
                context,
                '💶',
                '${_formatCurrency(eurAmount)} EUR',
              ),
              _buildCurrencyItem(
                context,
                '🥇',
                l10n.goldGrams(_formatCurrency(goldGrams, decimals: 1)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCurrencyItem(BuildContext context, String emoji, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(emoji, style: const TextStyle(fontSize: 14)),
        const SizedBox(width: 4),
        Text(
          text,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: context.appColors.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildTimeBlock({
    required BuildContext context,
    required String value,
    required String unit,
    required IconData icon,
  }) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                context.appColors.primary.withValues(alpha: 0.2),
                context.appColors.primary.withValues(alpha: 0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(AppDesign.radiusSmall),
          ),
          child: Icon(icon, size: 22, color: context.appColors.primary),
        ),
        const SizedBox(height: AppDesign.spacingSm),
        Text(
          value,
          style: TextStyle(
            fontSize: AppDesign.fontSizeDisplay,
            fontWeight: FontWeight.w800,
            color: context.appColors.textPrimary,
            letterSpacing: -1.5,
            height: 1,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          unit,
          style: TextStyle(
            fontSize: AppDesign.fontSizeSm,
            fontWeight: FontWeight.w500,
            color: context.appColors.textSecondary.withValues(alpha: 0.6),
          ),
        ),
      ],
    );
  }
}
